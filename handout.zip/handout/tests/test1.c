#include <stdio.h>

int main() {
  int numbers[3];
  for(int i = 0; i < 4; i++) {
    numbers[i] = i;
  }
  return 0;
}


